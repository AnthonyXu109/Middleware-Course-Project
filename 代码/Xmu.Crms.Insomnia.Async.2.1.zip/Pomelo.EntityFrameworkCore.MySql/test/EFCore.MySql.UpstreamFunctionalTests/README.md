Upstream Functional Tests
================================

**Configuring the Database**

You first must configure your MySql Database.  Open the `config.json.example` file, configure the connection string, and save it as `config.json`.

**Running Functional Tests**

1. Configure the Databse
2. Run `dotnet test`
3. This will run through all of the tests in the current directory.