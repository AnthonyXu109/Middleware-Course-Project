run scripts/rebuild.ps1 or scripts/rebuild.sh to instantiate the migrations and database
