﻿using System;
using System.IO;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.Loader;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Orleans;
using Orleans.Configuration;
using Orleans.Hosting;
using Xmu.Crms.Shared.Models;

namespace Xmu.Crms.Silo
{
    public class Program
    {
        private static ISiloHost _silo;
        private static readonly ManualResetEvent _SiloStopped = new ManualResetEvent(false);

        private static bool siloStopping = false;
        private static readonly object syncLock = new object();

        private static readonly IConfiguration _Configuration = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json", false, true)
            .AddJsonFile($"appsettings.{Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Production"}.json", true)
            .AddEnvironmentVariables()
            .Build();

        static void SetupApplicationShutdown() {
            /// Capture the user pressing Ctrl+C
            Console.CancelKeyPress += (s, a) => {
                /// Prevent the application from crashing ungracefully.
                a.Cancel = true;
                /// Don't allow the following code to repeat if the user presses Ctrl+C repeatedly.
                lock (syncLock) {
                    Console.Error.WriteLine("Silo stopping");                    
                    if (!siloStopping) {
                        siloStopping = true;
                        Task.Run(StopSilo).Ignore();
                    }
                }
                /// Event handler execution exits immediately, leaving the silo shutdown running on a background thread,
                /// but the app doesn't crash because a.Cancel has been set = true
            };
        }

        private static void Main()
        {
            SetupApplicationShutdown();

            _silo = new SiloHostBuilder()
                .UseAdoNetClustering(options =>
                {
                    options.Invariant = "MySql.Data.MySqlClient";
                    options.ConnectionString = _Configuration.GetConnectionString("MYSQL57");
                })
                .Configure<ClusterOptions>(options =>
                {
                    options.ClusterId = "xmu.crms.silo";
                    options.ServiceId = "xmu.crms.silo.services";
                })
                .ConfigureEndpoints(GetLocalIpAddress(), 11111, 30000)
                .ConfigureServices(svc =>
                {
                    svc.AddDbContextPool<CrmsContext>(options =>
                        options.UseMySQL(_Configuration.GetConnectionString("MYSQL57"))
                    );
                    svc
                        .AddViceVersaClassDao()
                        .AddViceVersaClassService()
                        .AddViceVersaCourseDao()
                        .AddViceVersaCourseService()
                        .AddViceVersaGradeDao()
                        .AddViceVersaGradeService()
                        .AddHighGradeSchoolService()
                        .AddHighGradeSeminarService()
                        .AddInsomniaFixedGroupService()
                        .AddInsomniaLoginService()
                        .AddInsomniaSeminarGroupService()
                        .AddInsomniaTopicService()
                        .AddInsomniaUserService();
                })
                .ConfigureApplicationParts(parts =>
                    parts.AddApplicationPart(typeof(HighGradeExtensions).Assembly).WithReferences())
                .ConfigureApplicationParts(parts =>
                    parts.AddApplicationPart(typeof(ViceVersaExtensions).Assembly).WithReferences())
                .ConfigureApplicationParts(parts =>
                    parts.AddApplicationPart(typeof(InsomniaExtensions).Assembly).WithReferences())
                .ConfigureLogging(builder => builder.SetMinimumLevel(LogLevel.Warning).AddConsole())
                .Build();

            Task.Run(StartSilo);

            _SiloStopped.WaitOne();
        }

        private static async Task StartSilo()
        {
            await _silo.StartAsync();
            Console.WriteLine("Silo started");
        }

        private static async Task StopSilo()
        {
            await _silo.StopAsync();
            Console.WriteLine("Silo stopped");
            _SiloStopped.Set();
        }

        public static IPAddress GetLocalIpAddress()
        {
            UnicastIPAddressInformation mostSuitableIp = null;

            var networkInterfaces = NetworkInterface.GetAllNetworkInterfaces();

            foreach (var network in networkInterfaces)
            {
                if (network.OperationalStatus != OperationalStatus.Up)
                {
                    continue;
                }

                var properties = network.GetIPProperties();

                if (properties.GatewayAddresses.Count == 0)
                {
                    continue;
                }

                foreach (var address in properties.UnicastAddresses)
                {
                    if (address.Address.AddressFamily != AddressFamily.InterNetwork)
                    {
                        continue;
                    }

                    if (IPAddress.IsLoopback(address.Address))
                    {
                        continue;
                    }

                    if (!address.IsDnsEligible)
                    {
                        if (mostSuitableIp == null)
                        {
                            mostSuitableIp = address;
                        }

                        continue;
                    }

                    // The best IP is the IP got from DHCP server
                    if (address.PrefixOrigin == PrefixOrigin.Dhcp)
                    {
                        return address.Address;
                    }

                    if (mostSuitableIp == null || !mostSuitableIp.IsDnsEligible)
                    {
                        mostSuitableIp = address;
                    }
                }
            }

            return mostSuitableIp?.Address;
        }
    }
}