﻿using Microsoft.AspNetCore.Identity;

namespace EFCore.MySql.FunctionalTests.Models
{
	public class AppIdentityUser : IdentityUser
	{
	}
}
