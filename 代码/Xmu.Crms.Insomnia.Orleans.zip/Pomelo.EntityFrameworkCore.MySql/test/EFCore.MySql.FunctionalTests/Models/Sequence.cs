namespace EFCore.MySql.FunctionalTests.Models
{

	public class Sequence
	{
		public int Id { get; set; }
	}

}
