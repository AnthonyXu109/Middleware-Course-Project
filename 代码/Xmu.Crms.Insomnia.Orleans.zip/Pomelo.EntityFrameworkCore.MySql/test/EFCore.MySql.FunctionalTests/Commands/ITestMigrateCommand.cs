namespace EFCore.MySql.FunctionalTests.Commands
{

    public interface ITestMigrateCommand
    {
        void Run();
    }

}
