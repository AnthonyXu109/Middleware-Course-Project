namespace EFCore.MySql.FunctionalTests.Commands
{

    public interface IConnectionStringCommand
    {
        void Run();
    }

}
