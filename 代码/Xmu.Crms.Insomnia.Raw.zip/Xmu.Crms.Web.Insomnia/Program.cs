﻿using System;

namespace Xmu.Crms.Web.Insomnia
{
    public class Program
    {
        public static void Main(string[] args)
        {
            throw new NotSupportedException();
        }
    }
}