﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Xmu.Crms.Mobile.HighGrade
{
    public class classController : Controller
    {
        public ActionResult FixedRollEndCallUI()
        {
            return View ();
        }
        public ActionResult FixedRollCallUI()
        {
            return View();
        }
        public ActionResult FixedRollStartCallUI()
        {
            return View();
        }
        public ActionResult RollCallListUI()
        {
            return View();
        }
    }
}
