﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Xmu.Crms.Mobile.HighGrade
{
    public class meController : Controller
    {
        public ActionResult CheckStudentInfoUI()
        {
            return View ();
        }
        public ActionResult CheckTeacherInfoUI()
        {
            return View();
        }
        public ActionResult LoginUI()
        {
            return View();
        }
        public ActionResult ChooseCharacter()
        {
            return View();
        }
        public ActionResult RegisterUI()
        {
            return View();
        }
        public ActionResult StudentBindingUI()
        {
            return View();
        }
        public ActionResult StudentMainUI()
        {
            return View();
        }
        public ActionResult TeacherBindingUI()
        {
            return View();
        }
        public ActionResult TeacherMainUI()
        {
            return View();
        }
    }
}
