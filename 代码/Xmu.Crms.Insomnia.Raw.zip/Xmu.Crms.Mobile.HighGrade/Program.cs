﻿using System;

namespace Xmu.Crms.Web.HighGrade
{
    public class Program
    {
        //示例界面，这个Main函数得有但是没作用
        //将静态文件放在 wwwroot 目录
        //模版文件放在 Views 目录
        public static void Main(string[] args)
        {
            throw new NotSupportedException();
        }
    }
}